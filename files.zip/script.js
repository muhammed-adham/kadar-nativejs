// ========== GLOBAL STATE & CONFIGURATION ==========
const appState = {
    currentPage: 'home',
    direction: localStorage.getItem('direction') || 'ltr',
    language: localStorage.getItem('language') || 'en',
    theme: localStorage.getItem('theme') || 'light',
    currentSlide: 0,
    selectedCategory: '',
    selectedSubcategory: '',
};

// ========== NAVIGATION DATA ==========
const navigationLinks = [
    { id: 'home', label_en: 'home', label_ar: 'الصفحة الرئيسية', path: '#home' },
    { id: 'about', label_en: 'about', label_ar: 'عن المصنع', path: '#about' },
    {
        id: 'products',
        label_en: 'Products',
        label_ar: 'المنتجات',
        path: '#products',
        dropdown: [
            { label_en: 'Civilian Products', label_ar: 'المنتجات المدنية', path: '#products' },
            { label_en: 'Furnish Your Home', label_ar: 'مبادرة أفرش بيتك', path: '#products' },
            { label_en: 'Hotel Furniture', label_ar: 'الأثاث الفندقي', path: '#products' },
            { label_en: 'Corporate Products', label_ar: 'منتجات الشركات', path: '#products' },
            { label_en: 'Military Products', label_ar: 'المنتجات العسكرية', path: '#products' },
        ]
    },
    { id: 'projects', label_en: 'projects', label_ar: 'المشاريع', path: '#projects' },
    { id: 'contact', label_en: 'contact Us', label_ar: 'أتصل بنا', path: '#contact' },
    { id: 'news', label_en: 'news', label_ar: 'آخر الأخبار', path: '#news' },
    { id: 'videos', label_en: 'video-library', label_ar: 'معرض الفيديوهات', path: '#videos' },
];

// ========== SLIDER DATA ==========
const sliderData = {
    en: [
        {
            title: 'Technology Centers',
            subTitle: 'Diverse Industries, Unified Excellence',
            text: 'Explore our state-of-the-art technology centers, equipped with cutting-edge tools and innovations.',
            url: '/images/b-1.jpg',
        },
        {
            title: 'Home Furniture',
            subTitle: 'Diverse Industries, Unified Excellence',
            text: 'Transform your living spaces with our premium home furniture collection.',
            url: '/images/prd-3.webp',
        },
        {
            title: 'Electronic Motorbikes',
            subTitle: 'Diverse Industries, Unified Excellence',
            text: 'Discover our range of eco-friendly electronic motorbikes.',
            url: '/images/b-2.jpg',
        },
    ],
    ar: [
        {
            title: 'مراكز التكنولوجيا',
            subTitle: 'صناعات متنوعة، تميز موحد',
            text: 'اكتشف مراكز التكنولوجيا الحديثة لدينا والمجهزة بأحدث الأدوات والابتكارات.',
            url: '/images/b-1.jpg',
        },
        {
            title: 'أثاث المنزل',
            subTitle: 'صناعات متنوعة، تميز موحد',
            text: 'حوّل مساحات معيشتك مع مجموعة أثاث المنزل الفاخرة لدينا.',
            url: '/images/prd-3.webp',
        },
        {
            title: 'المركبات الإلكترونية',
            subTitle: 'صناعات متنوعة، تميز موحد',
            text: 'اكتشف مجموعة المركبات الإلكترونية الصديقة للبيئة.',
            url: '/images/b-2.jpg',
        },
    ]
};

// ========== PRODUCTS DATA ==========
const productsData = {
    en: [
        {
            title: 'Transport Vehicles',
            desc: 'Explore our wide range of high-quality transport vehicles.',
            url: '/images/prd-1.webp',
            category: 'home furniture',
            sub_category: 'Master Room',
        },
        {
            title: 'Transport Vehicles',
            desc: 'High-quality office furniture solutions.',
            url: '/images/prd-2.webp',
            category: 'office furniture',
            sub_category: 'Hydraulic chairs',
        },
        {
            title: 'Transport Vehicles',
            desc: 'Modern office setup.',
            url: '/images/prd-3.webp',
            category: 'office furniture',
            sub_category: 'Work cell',
        },
    ],
    ar: [
        {
            title: 'مركبات النقل',
            desc: 'استكشف مجموعة واسعة من مركبات النقل عالية الجودة.',
            url: '/images/prd-1.webp',
            category: 'أثاث المنزل',
            sub_category: 'غرفة النوم',
        },
    ]
};

// ========== UTILITY FUNCTIONS ==========

/**
 * Get text based on current language
 */
function getText(obj, key) {
    const currentLang = appState.language === 'ar' ? 'ar' : 'en';
    return obj[`${key}_${currentLang}`] || obj[key] || '';
}

/**
 * Get label based on language
 */
function getLabel(en, ar) {
    return appState.language === 'ar' ? ar : en;
}

/**
 * Get CSS class for direction
 */
function getDirectionClass(enClass, arClass) {
    return appState.direction === 'rtl' ? arClass : enClass;
}

/**
 * Toggle theme (light/dark)
 */
function toggleTheme() {
    const newTheme = appState.theme === 'light' ? 'dark' : 'light';
    appState.theme = newTheme;
    localStorage.setItem('theme', newTheme);
    document.body.setAttribute('data-theme', newTheme);
    updateLogoBasedOnTheme();
}

/**
 * Update logo based on theme
 */
function updateLogoBasedOnTheme() {
    const logoImg = document.getElementById('logoImg');
    if (logoImg) {
        if (appState.theme === 'dark') {
            logoImg.src = '/images/logo-kader-white.png';
        } else {
            logoImg.src = '/images/logo-kader.png';
        }
    }
}

/**
 * Toggle language and direction
 */
function toggleLanguage() {
    const newLang = appState.language === 'ar' ? 'en' : 'ar';
    const newDir = appState.direction === 'ltr' ? 'rtl' : 'ltr';
    
    appState.language = newLang;
    appState.direction = newDir;
    
    localStorage.setItem('language', newLang);
    localStorage.setItem('direction', newDir);
    
    document.documentElement.lang = newLang;
    document.documentElement.dir = newDir;
    
    location.reload();
}

/**
 * Initialize navigation
 */
function initializeNavigation() {
    const navContainer = document.querySelector('.navbar-nav');
    if (!navContainer) return;

    navContainer.innerHTML = '';

    navigationLinks.forEach((link, index) => {
        const isDropdown = link.dropdown && link.dropdown.length > 0;
        
        if (isDropdown) {
            const dropdownHTML = `
                <div class="nav-item dropdown">
                    <a class="nav-link" href="#${link.id}" role="button" data-bs-toggle="dropdown">
                        <span class="dropdown-toggle">${getLabel(link.label_en, link.label_ar)}</span>
                    </a>
                    <div class="dropdown-menu">
                        ${link.dropdown.map(item => `
                            <a class="dropdown-item" href="#products" onclick="setCurrentPage('products')">
                                ${getLabel(item.label_en, item.label_ar)}
                            </a>
                        `).join('')}
                    </div>
                </div>
            `;
            navContainer.innerHTML += dropdownHTML;
        } else {
            const linkHTML = `
                <a class="nav-item nav-link" href="#${link.id}" onclick="setCurrentPage('${link.id}')" id="nav-${link.id}">
                    ${getLabel(link.label_en, link.label_ar)}
                </a>
            `;
            navContainer.innerHTML += linkHTML;
        }
    });

    // Add separator line
    navContainer.innerHTML += '<div class="d-none d-lg-block vertical-line m-4"></div>';

    // Add theme toggle
    navContainer.innerHTML += `
        <div class="nav-item dropdown">
            <a class="nav-link" href="#" role="button" data-bs-toggle="dropdown">
                <span class="dropdown-toggle">
                    <i class="fas fa-${appState.theme === 'dark' ? 'moon' : 'sun'} mx-1"></i>
                    ${getLabel('Theme', 'الوضع')}
                </span>
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" onclick="toggleTheme()">
                    ${appState.theme === 'dark' ? getLabel('Light', 'الوضع الفاتح') : getLabel('Dark', 'الوضع الداكن')}
                </a>
            </div>
        </div>
    `;

    // Add language toggle
    navContainer.innerHTML += `
        <div class="nav-item dropdown">
            <a class="nav-link" href="#" role="button" data-bs-toggle="dropdown">
                <span class="dropdown-toggle">
                    <i class="fas fa-globe mx-1"></i>
                    ${appState.language === 'ar' ? 'ع' : 'EN'}
                </span>
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" onclick="toggleLanguage()">
                    ${appState.language === 'ar' ? 'English' : 'العربية'}
                </a>
            </div>
        </div>
    `;

    // Add search button
    navContainer.innerHTML += `
        <button class="btn btn-primary btn-sm border-secondary" data-bs-toggle="modal" data-bs-target="#searchModal">
            <i class="fa fa-search"></i>
        </button>
    `;
}

/**
 * Initialize slider/carousel
 */
function initializeSlider() {
    const currentData = appState.language === 'ar' ? sliderData.ar : sliderData.en;
    const indicatorsContainer = document.getElementById('carouselIndicators');
    const innerContainer = document.getElementById('carouselInner');

    if (!indicatorsContainer || !innerContainer) return;

    // Clear existing content
    indicatorsContainer.innerHTML = '';
    innerContainer.innerHTML = '';

    // Add indicators
    currentData.forEach((_, index) => {
        const indicator = document.createElement('li');
        indicator.setAttribute('data-bs-target', '#carouselId');
        indicator.setAttribute('data-bs-slide-to', index);
        indicator.className = index === 0 ? 'active' : '';
        indicatorsContainer.appendChild(indicator);
    });

    // Add carousel items
    currentData.forEach((slide, index) => {
        const item = document.createElement('div');
        item.className = `carousel-item ${index === 0 ? 'active' : ''}`;
        item.innerHTML = `
            <img src="${slide.url}" class="d-block w-100" alt="Slide ${index + 1}" style="height: 500px; object-fit: cover;">
            <div class="carousel-caption">
                <div class="text-center p-4" style="max-width: 900px;">
                    <h4 class="text-white text-uppercase fw-bold mb-3 wow fadeInUp">${slide.subTitle}</h4>
                    <h1 class="display-1 text-white mb-3 wow fadeInUp text-capitalize">${slide.title}</h1>
                    <p class="text-white mb-4 fs-5 wow fadeInUp">${slide.text}</p>
                    <a href="#products" onclick="setCurrentPage('products')" class="btn btn-primary border-secondary text-white py-3 px-5 wow fadeInUp rounded-0">
                        ${getLabel('More Details', 'المزيد من التفاصيل')}
                    </a>
                </div>
            </div>
        `;
        innerContainer.appendChild(item);
    });

    // Auto-slide functionality
    setInterval(() => {
        const carousel = bootstrap.Carousel.getInstance(document.getElementById('carouselId'));
        if (carousel) carousel.next();
    }, 3000);
}

/**
 * Initialize footer
 */
function initializeFooter() {
    const footer = document.getElementById('mainFooter');
    if (!footer) return;

    footer.innerHTML = `
        <div class="container-fluid footer bg-primary py-5">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-md-6 col-lg-3">
                        <div class="footer-item d-flex flex-column">
                            <h4 class="text-white mb-4">${getLabel('Contact Info', 'تواصل معنا')}</h4>
                            <a href=""><i class="fa fa-map-marker-alt m-2"></i> ${getLabel('2 El Tayaran St, Nasr City', '2 ش الطيران، مدينة نصر')}</a>
                            <a href="mailto:marketing@kader-factory.com"><i class="fa fa-envelope m-2"></i> marketing@kader-factory</a>
                            <a href="tel:+201030009248"><i class="fa fa-phone m-2"></i> <span dir="ltr">+2010 3000 9248</span></a>
                            <a href="https://wa.me/201030009248" target="_blank"><i class="fa fa-comment m-2"></i> <span dir="ltr">+2010 3000 9248</span></a>
                            <div class="d-flex align-items-center mt-3">
                                <i class="fas fa-share fa-2x text-secondary m-2"></i>
                                <a class="btn mx-1" href="https://www.facebook.com/kader.factory.eg/" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn mx-1" href="https://www.youtube.com/@kaderfactory8960" target="_blank"><i class="fab fa-youtube"></i></a>
                                <a class="btn mx-1" href="https://www.instagram.com/kader_factory_official/" target="_blank"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-2">
                        <div class="footer-item d-flex flex-column">
                            <h4 class="text-white mb-4">${getLabel('Explore', 'استكشف')}</h4>
                            ${navigationLinks.map(link => !link.dropdown ? `
                                <a href="#${link.id}" onclick="setCurrentPage('${link.id}')">
                                    <i class="fas fa-angle-right m-2"></i> ${getLabel(link.label_en, link.label_ar)}
                                </a>
                            ` : '').join('')}
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="footer-item d-flex flex-column">
                            <h4 class="text-white mb-4">${getLabel('Our Services', 'الأقسام')}</h4>
                            <a href="#products"><i class="fas fa-angle-right m-2"></i> ${getLabel('Products', 'المنتجات')}</a>
                            <a href="#projects"><i class="fas fa-angle-right m-2"></i> ${getLabel('Projects', 'المشاريع')}</a>
                            <a href="#news"><i class="fas fa-angle-right m-2"></i> ${getLabel('News', 'الأخبار')}</a>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4">
                        <div class="footer-item">
                            <h4 class="text-white mb-4">${getLabel('Newsletter', 'الرسائل الإخبارية')}</h4>
                            <p class="text-white mb-3">${getLabel('Be the first to know about new products', 'كن أول المطلعين على المنتجات الجديدة')}</p>
                            <div class="input-group rounded-pill">
                                <input type="email" class="form-control" placeholder="${getLabel('Enter your email', 'ادخل بريدك الالكتروني')}">
                                <button class="btn btn-secondary rounded-0">
                                    ${getLabel('SignUp', 'اشتراك')}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid copyright py-4 bg-white">
            <div class="container">
                <div class="row g-4 align-items-center">
                    <div class="col-md-6">
                        <span class="text-dark">
                            ${getLabel(
                                'Copyright © Kader Factory for Advanced Industries, 2025. All rights reserved',
                                'حقوق النشر © مصنع قادر للصناعات المتطورة، 2025. جميع الحقوق محفوظة'
                            )}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Create banner component
 */
function createBanner(title) {
    return `
        <div class="container-fluid bg-breadcrumb bg-primary">
            <div class="container text-center py-5">
                <h3 class="text-white display-3 mb-4 text-capitalize">${title}</h3>
                <ol class="breadcrumb justify-content-center text-white mb-0">
                    <li class="breadcrumb-item">
                        <a href="#" class="text-white" onclick="setCurrentPage('home')">${getLabel('Home', 'الرئيسية')}</a>
                    </li>
                    <span class="px-2" style="opacity: 0.3;">|</span>
                    <li class="breadcrumb-item active text-secondary text-capitalize">${title}</li>
                </ol>
            </div>
        </div>
    `;
}

/**
 * Create counter section
 */
function createCounterSection() {
    return `
        <div class="container-fluid counter-facts bg-white py-5">
            <div class="container py-5">
                <div class="row g-4">
                    <div class="col-12 col-sm-6 col-md-6 col-xl-3">
                        <div class="counter">
                            <div class="counter-icon"><i class="fas fa-passport"></i></div>
                            <div class="counter-content">
                                <h3>${getLabel('Technological Centers', 'مراكز التكنولوجيا')}</h3>
                                <div class="d-flex align-items-center justify-content-center">
                                    <span class="counter-value">31</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-6 col-xl-3">
                        <div class="counter">
                            <div class="counter-icon"><i class="fas fa-users"></i></div>
                            <div class="counter-content">
                                <h3>${getLabel('Firefighting Cars', 'سيارات الإطفاء')}</h3>
                                <div class="d-flex align-items-center justify-content-center">
                                    <span class="counter-value">11</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-6 col-xl-3">
                        <div class="counter">
                            <div class="counter-icon"><i class="fas fa-user-check"></i></div>
                            <div class="counter-content">
                                <h3>${getLabel('Home Furniture', 'أثاث المنزل')}</h3>
                                <div class="d-flex align-items-center justify-content-center">
                                    <span class="counter-value">13</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-md-6 col-xl-3">
                        <div class="counter">
                            <div class="counter-icon"><i class="fas fa-handshake"></i></div>
                            <div class="counter-content">
                                <h3>${getLabel('Office Furniture', 'أثاث المكاتب')}</h3>
                                <div class="d-flex align-items-center justify-content-center">
                                    <span class="counter-value">20</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Set current page and update display
 */
function setCurrentPage(pageId) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.style.display = 'none';
    });

    // Show selected page
    const selectedPage = document.getElementById(`${pageId}-page`);
    if (selectedPage) {
        selectedPage.style.display = 'block';
        appState.currentPage = pageId;
        
        // Update active navigation link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        const activeLink = document.getElementById(`nav-${pageId}`);
        if (activeLink) activeLink.classList.add('active');
        
        // Scroll to top
        window.scrollTo(0, 0);
        
        // Load page-specific content if needed
        loadPageContent(pageId);
    }
}

/**
 * Load page-specific content
 */
function loadPageContent(pageId) {
    switch(pageId) {
        case 'about':
            loadAboutPage();
            break;
        case 'products':
            loadProductsPage();
            break;
        case 'projects':
            loadProjectsPage();
            break;
        case 'news':
            loadNewsPage();
            break;
        case 'videos':
            loadVideosPage();
            break;
        case 'contact':
            loadContactPage();
            break;
    }
}

/**
 * Load about page
 */
function loadAboutPage() {
    const container = document.getElementById('aboutPageContent');
    if (!container) return;

    container.innerHTML = `
        ${createBanner(getLabel('About Us', 'من نحن'))}
        <div class="container-fluid overflow-hidden py-5 bg-white">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-xl-5 wow fadeInRight" data-wow-delay="0.1s">
                        <div class="bg-light rounded" style="height: 100%; width: 100%;">
                            <img src="/images/about.webp" class="img-fluid w-100" style="width: 100%; height: 100%; object-fit: cover;" alt="About">
                        </div>
                    </div>
                    <div class="col-xl-7 wow fadeInRight" data-wow-delay="0.3s">
                        <h5 class="sub-title p-3">${getLabel('About KADER', 'عن مصنع قادر')}</h5>
                        <h1 class="display-5 mb-4">${getLabel('We\'re Trusted Factory Affiliated with AOI', 'نحن مصنع موثوق به ومعتمد من الهيئة العربية للتصنيع')}</h1>
                        <p class="mb-4">${getLabel('At KADER, we pride ourselves on decades of expertise and innovation in manufacturing.', 'في مصنع قادر، نفخر بعقود من الخبرة والابتكار في مجال التصنيع.')}</p>
                        <div class="row gy-4 align-items-center">
                            <div class="col-4 col-md-3">
                                <div class="bg-light text-center rounded p-3">
                                    <div class="mb-2">
                                        <i class="fas fa-ticket-alt fa-4x text-primary"></i>
                                    </div>
                                    <h1 class="display-5 fw-bold mb-2 text-dark">70+</h1>
                                    <p class="text-muted mb-0">${getLabel('Years of Experience', 'سنوات من الخبرة')}</p>
                                </div>
                            </div>
                            <div class="col-8 col-md-9">
                                <div class="d-flex flex-wrap">
                                    <div class="d-flex align-items-center justify-content-center m-4">
                                        <i class="fa fa-phone-alt text-primary fa-3x"></i>
                                    </div>
                                    <div class="d-flex flex-column justify-content-center">
                                        <span class="text-primary">${getLabel('Have any questions?', 'هل لديك أي أسئلة؟')}</span>
                                        <span class="text-secondary fw-bold fs-5">call: <span dir="ltr">+0123 456 7890</span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        ${createCounterSection()}
    `;
}

/**
 * Load products page
 */
function loadProductsPage() {
    const container = document.getElementById('productsPageContent');
    if (!container) return;

    const productHTML = `
        ${createBanner(getLabel('Products', 'المنتجات'))}
        <div class="container-fluid service overflow-hidden py-5">
            <div class="container py-5">
                <div class="section-title text-center mb-5">
                    <div class="sub-style">
                        <h5 class="sub-title text-primary px-3">${getLabel('CHECK OUR PRODUCTS', 'اكتشف المنتجات')}</h5>
                    </div>
                    <h1 class="display-5 mb-4">${getLabel('Offer Tailor Made Products', 'منتجات مخصصة حسب احتياجاتك')}</h1>
                    <p class="mb-0">${getLabel('Discover our wide range of high-quality products', 'استكشف مجموعة واسعة من المنتجات عالية الجودة')}</p>
                </div>
                <div class="row g-4">
                    <div class="col-lg-6 col-xl-4">
                        <div class="service-item">
                            <div class="service-inner">
                                <div class="service-img" style="height: 16rem;">
                                    <img src="/images/b-5.jpg" class="img-fluid w-100 rounded" alt="Transport" style="width: 100%; height: 100%; object-fit: contain;">
                                </div>
                                <div class="service-title">
                                    <div class="service-title-name">
                                        <div class="bg-primary text-center rounded-0 p-3 mx-5 mb-4">
                                            <a href="#" class="h4 text-white mb-0">${getLabel('Transport Vehicles', 'مركبات النقل')}</a>
                                        </div>
                                        <a class="btn bg-white shadow-sm text-secondary rounded-0 py-3 px-5 mb-4" href="#">
                                            ${getLabel('Explore More', 'استكشف المزيد')}
                                        </a>
                                    </div>
                                    <div class="service-content pb-4 bg-primary">
                                        <h4 class="text-white mb-4 py-3">${getLabel('Transport Vehicles', 'مركبات النقل')}</h4>
                                        <div class="px-4">
                                            <p class="mb-4">${getLabel('High-quality transport solutions', 'حلول نقل عالية الجودة')}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    container.innerHTML = productHTML;
}

/**
 * Load projects page
 */
function loadProjectsPage() {
    const container = document.getElementById('projectsPageContent');
    if (!container) return;

    container.innerHTML = `
        ${createBanner(getLabel('Projects', 'المشاريع'))}
        <div class="container-fluid training overflow-hidden py-5">
            <div class="container py-5">
                <div class="section-title text-left mb-5">
                    <div class="sub-style">
                        <h5 class="sub-title text-primary px-3">${getLabel('Our Projects', 'مشاريعنا')}</h5>
                    </div>
                    <h1 class="display-5 mb-4">${getLabel('Projects that demonstrate our professionalism', 'مشاريع تثبت مستوى احترافيتنا')}</h1>
                    <p class="mb-0">${getLabel('This page showcases our latest projects', 'تعرض هذه الصفحة أحدث مشاريعنا')}</p>
                </div>
                <div class="row g-4">
                    <div class="col-lg-6 col-xl-4">
                        <div class="training-item">
                            <div class="training-inner" style="height: 32rem;">
                                <img src="/images/pro-1.jpg" class="img-fluid w-100 rounded" alt="Project">
                            </div>
                            <div class="training-content bg-secondary rounded-bottom p-4">
                                <h4 class="text-white">${getLabel('Project 1', 'المشروع 1')}</h4>
                                <p class="text-white-50">Lorem ipsum dolor sit amet consectetur</p>
                                <a href="#" class="btn btn-secondary rounded-pill text-white p-0">
                                    ${getLabel('Read More', 'اقرأ المزيد')} <i class="fas fa-arrow-right px-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Load news page
 */
function loadNewsPage() {
    const container = document.getElementById('newsPageContent');
    if (!container) return;

    container.innerHTML = `
        ${createBanner(getLabel('News', 'الأخبار'))}
        <div class="container-fluid training overflow-hidden py-5">
            <div class="container py-5">
                <div class="section-title text-left mb-5">
                    <div class="sub-style">
                        <h5 class="sub-title text-primary px-3">${getLabel('News', 'الأخبار')}</h5>
                    </div>
                    <h1 class="display-5 mb-4">${getLabel('Stay Informed on the Latest Updates', 'ابق على اطلاع بأحدث المستجدات')}</h1>
                </div>
                <div class="row g-4">
                    <div class="col-lg-6 col-xl-6">
                        <div class="training-item">
                            <div class="training-inner" style="height: 24rem;">
                                <img src="/images/news-1.webp" class="img-fluid w-100 rounded" alt="News">
                            </div>
                            <div class="training-content bg-secondary rounded-bottom p-4">
                                <h4 class="text-white">${getLabel('Latest News', 'أحدث الأخبار')}</h4>
                                <p class="text-white-50">Lorem ipsum dolor sit amet</p>
                                <a href="#" class="btn btn-secondary rounded-pill text-white p-0">
                                    ${getLabel('Read More', 'اقرأ المزيد')} <i class="fas fa-arrow-right px-1"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Load videos page
 */
function loadVideosPage() {
    const container = document.getElementById('videosPageContent');
    if (!container) return;

    container.innerHTML = `
        ${createBanner(getLabel('Video Library', 'معرض الفيديوهات'))}
        <div class="container-fluid training overflow-hidden py-5">
            <div class="container py-5">
                <div class="section-title text-center mb-5">
                    <h5 class="sub-title text-primary px-3">${getLabel('Video Gallery', 'معرض الفيديو')}</h5>
                    <h1 class="display-5 mb-4">${getLabel('Explore Our Visual Content', 'استكشف محتوانا المرئي')}</h1>
                </div>
                <div class="row g-5">
                    <div class="col-lg-6 col-xl-3">
                        <div class="position-relative" style="padding-bottom: 56.25%; height: 0; overflow: hidden;">
                            <iframe style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" 
                                src="https://www.youtube.com/embed/dY3t90L_q3Q" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Load contact page
 */
function loadContactPage() {
    const container = document.getElementById('contactPageContent');
    if (!container) return;

    container.innerHTML = `
        ${createBanner(getLabel('Contact Us', 'اتصل بنا'))}
        <div class="container-fluid contact overflow-hidden py-5">
            <div class="container py-5">
                <div class="row g-5 mb-5">
                    <div class="col-lg-6">
                        <h5 class="sub-title text-primary p-3">${getLabel('Quick Contact', 'اتصل بنا')}</h5>
                        <h1 class="display-5 mb-4">${getLabel('Have Questions?', 'هل لديك أسئلة؟')}</h1>
                        <div class="d-flex border-bottom mb-4 pb-4">
                            <i class="fas fa-map-marked-alt fa-4x text-primary px-3 rounded"></i>
                            <div class="ps-3">
                                <h5>${getLabel('Location', 'الموقع')}</h5>
                                <p>${getLabel('2 El Tayaran St, Al Golf, Nasr City', '2 شارع الطياران، الجولف، مدينة نصر')}</p>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-xl-6">
                                <div class="d-flex">
                                    <i class="fas fa-tty fa-3x text-primary px-3"></i>
                                    <div class="ps-3">
                                        <h5>${getLabel('Quick Contact', 'اتصل بنا')}</h5>
                                        <p><strong>${getLabel('Phone', 'الهاتف')}:</strong> <a href="tel:+201030009248" dir="ltr">+2010 3000 9248</a></p>
                                        <p><strong>${getLabel('Email', 'البريد')}:</strong> <a href="mailto:marketing@kader-factory.com">marketing@kader-factory.com</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <h5 class="sub-title text-primary p-3">${getLabel('Let\'s Connect', 'لنتواصل')}</h5>
                        <form>
                            <div class="row g-4">
                                <div class="col-12">
                                    <input type="text" class="form-control" placeholder="${getLabel('Your Name', 'اسمك')}">
                                </div>
                                <div class="col-12">
                                    <input type="email" class="form-control" placeholder="${getLabel('Your Email', 'بريدك الإلكتروني')}">
                                </div>
                                <div class="col-12">
                                    <input type="text" class="form-control" placeholder="${getLabel('Subject', 'الموضوع')}">
                                </div>
                                <div class="col-12">
                                    <textarea class="form-control" rows="5" placeholder="${getLabel('Message', 'الرسالة')}"></textarea>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary w-100 py-3 rounded-0">
                                        ${getLabel('Send Message', 'إرسال')}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="office pt-5">
                    <div class="row g-4 justify-content-center">
                        <div class="col-12 pt-5">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1726.2533249816152!2d31.31804038889666!3d30.07967296942901!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14583f17819003bd%3A0x5788391b0502453f!2sKader%20Factory" 
                                class="rounded w-100" style="height: 500px;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

/**
 * Initialize home page sections
 */
function initializeHomePageSections() {
    // Initialize About Section
    const aboutSection = document.getElementById('aboutSection');
    if (aboutSection) {
        aboutSection.innerHTML = `
            <div class="container-fluid overflow-hidden py-5 bg-white" style="width: 80%;">
                <div class="container py-5">
                    <div class="row g-5">
                        <div class="col-xl-5 wow fadeInLeft" data-wow-delay="0.1s">
                            <div class="bg-light rounded" style="height: 100%; width: 100%;">
                                <img src="/images/about.webp" class="img-fluid w-100" style="width: 100%; height: 100%; object-fit: cover;" alt="About">
                            </div>
                        </div>
                        <div class="col-xl-7 wow fadeInRight" data-wow-delay="0.3s">
                            <h5 class="sub-title p-3">${getLabel('About KADER', 'عن مصنع قادر')}</h5>
                            <h1 class="display-5 mb-4">${getLabel('We\'re Trusted Factory Affiliated with AOI', 'نحن مصنع موثوق به')}</h1>
                            <p class="mb-4">${getLabel('At KADER, we pride ourselves on decades of expertise and innovation.', 'في مصنع قادر، نفخر بعقود من الخبرة والابتكار.')}</p>
                            <div class="row gy-4 align-items-center">
                                <div class="col-4 col-md-3">
                                    <div class="bg-light text-center rounded p-3">
                                        <div class="mb-2"><i class="fas fa-ticket-alt fa-4x text-primary"></i></div>
                                        <h1 class="display-5 fw-bold mb-2 text-dark">70+</h1>
                                        <p class="text-muted mb-0">${getLabel('Years of Experience', 'سنوات من الخبرة')}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Initialize Products Section
    const productsSection = document.getElementById('productsSection');
    if (productsSection) {
        productsSection.innerHTML = `
            <div class="container-fluid service overflow-hidden py-5">
                <div class="container py-5">
                    <div class="section-title text-center mb-5">
                        <h5 class="sub-title text-primary px-3">${getLabel('Our Products', 'منتجاتنا')}</h5>
                        <h1 class="display-5 mb-4">${getLabel('Top Products', 'أفضل المنتجات')}</h1>
                    </div>
                    <div class="row g-4">
                        <div class="col-lg-6 col-xl-4">
                            <div class="service-item">
                                <div class="service-inner">
                                    <div class="service-img" style="height: 16rem;">
                                        <img src="/images/b-5.jpg" class="img-fluid w-100 rounded" alt="Transport">
                                    </div>
                                    <div class="service-title">
                                        <div class="service-title-name">
                                            <div class="bg-primary text-center rounded-0 p-3 mx-5 mb-4">
                                                <a href="#" class="h4 text-white mb-0">${getLabel('Transport Vehicles', 'مركبات النقل')}</a>
                                            </div>
                                            <a class="btn bg-white shadow-sm text-secondary rounded-0 py-3 px-5 mb-4" href="#" onclick="setCurrentPage('products')">
                                                ${getLabel('Explore More', 'استكشف المزيد')}
                                            </a>
                                        </div>
                                        <div class="service-content pb-4 bg-primary">
                                            <h4 class="text-white mb-4 py-3">${getLabel('Transport Vehicles', 'مركبات النقل')}</h4>
                                            <div class="px-4">
                                                <p class="mb-4">High-quality transport solutions</p>
                                                <a class="btn btn-primary border-secondary rounded-0 text-white py-3 px-5" href="#" onclick="setCurrentPage('products')">
                                                    ${getLabel('Explore More', 'استكشف المزيد')}
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 text-center pt-3">
                        <a class="btn btn-primary border-secondary rounded-0 py-3 px-5" href="#" onclick="setCurrentPage('products')">
                            ${getLabel('View All', 'عرض الكل')}
                        </a>
                    </div>
                </div>
            </div>
        `;
    }

    // Initialize News Section
    const newsSection = document.getElementById('newsSection');
    if (newsSection) {
        newsSection.innerHTML = `
            <div class="container-fluid training overflow-hidden pb-5">
                <div class="container py-5">
                    <div class="section-title text-center mb-5">
                        <h5 class="sub-title text-primary px-3">${getLabel('News', 'الأخبار')}</h5>
                        <h1 class="display-5 mb-4">${getLabel('Here Is Our Latest News', 'إليكم أحدث أخبارنا')}</h1>
                    </div>
                    <div class="row g-4">
                        <div class="col-lg-6 col-xl-4">
                            <div class="training-item">
                                <div class="training-inner" style="height: 18rem;">
                                    <img src="/images/news-1.webp" class="img-fluid w-100 rounded" alt="News">
                                </div>
                                <div class="training-content bg-secondary rounded-bottom p-4">
                                    <h4 class="text-white">${getLabel('Latest News', 'أحدث خبر')}</h4>
                                    <p class="text-white-50">Lorem ipsum dolor sit amet</p>
                                    <a href="#" class="btn btn-secondary rounded-pill text-white p-0" onclick="setCurrentPage('news')">
                                        ${getLabel('Read More', 'اقرأ المزيد')} <i class="fas fa-arrow-right px-1"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 text-center pt-5">
                        <a class="btn btn-primary border-secondary rounded-0 py-3 px-5" href="#" onclick="setCurrentPage('news')">
                            ${getLabel('View All', 'عرض الكل')}
                        </a>
                    </div>
                </div>
            </div>
        `;
    }

    // Initialize Projects Section
    const projectsSection = document.getElementById('projectsSection');
    if (projectsSection) {
        projectsSection.innerHTML = `
            <div class="container-fluid training overflow-hidden py-5">
                <div class="container py-5">
                    <div class="section-title text-center mb-5">
                        <h5 class="sub-title text-primary px-3">${getLabel('Our Projects', 'مشاريعنا')}</h5>
                        <h1 class="display-5 mb-4">${getLabel('Projects that demonstrate our professionalism', 'مشاريع تثبت مستوى احترافيتنا')}</h1>
                    </div>
                    <div class="row g-4">
                        <div class="col-lg-6 col-xl-4">
                            <div class="training-item">
                                <div class="training-inner" style="height: 32rem;">
                                    <img src="/images/pro-1.jpg" class="img-fluid w-100 rounded" alt="Project">
                                </div>
                                <div class="training-content bg-secondary rounded-bottom p-4">
                                    <h4 class="text-white">${getLabel('Project 1', 'المشروع 1')}</h4>
                                    <p class="text-white-50">Lorem ipsum dolor sit amet</p>
                                    <a href="#" class="btn btn-secondary rounded-pill text-white p-0" onclick="setCurrentPage('projects')">
                                        ${getLabel('Read More', 'اقرأ المزيد')} <i class="fas fa-arrow-right px-1"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
}

/**
 * Initialize the application
 */
function initializeApp() {
    // Set initial direction and language
    document.documentElement.lang = appState.language;
    document.documentElement.dir = appState.direction;
    document.body.setAttribute('data-theme', appState.theme);

    // Initialize components
    initializeNavigation();
    initializeSlider();
    initializeFooter();
    initializeHomePageSections();
    updateLogoBasedOnTheme();

    // Setup event listeners
    setupEventListeners();

    // Show home page
    setCurrentPage('home');
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Mobile nav toggler
    const toggler = document.getElementById('navbarToggler');
    const navCollapse = document.getElementById('navbarCollapse');
    
    if (toggler) {
        toggler.addEventListener('click', () => {
            navCollapse.classList.toggle('show');
        });
    }

    // Home logo click
    const homeLogo = document.getElementById('homeLogo');
    if (homeLogo) {
        homeLogo.addEventListener('click', (e) => {
            e.preventDefault();
            setCurrentPage('home');
        });
    }

    // Sticky navbar on scroll
    window.addEventListener('scroll', () => {
        const navbar = document.getElementById('mainNav');
        if (window.scrollY > 45) {
            navbar.classList.add('sticky-top', 'shadow-sm');
        } else {
            navbar.classList.remove('sticky-top', 'shadow-sm');
        }
    });

    // Handle hash navigation
    window.addEventListener('hashchange', () => {
        const hash = window.location.hash.substring(1);
        if (hash) setCurrentPage(hash);
    });
}

/**
 * Scroll to top utility
 */
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', initializeApp);

// Expose functions to global scope for inline event handlers
window.setCurrentPage = setCurrentPage;
window.toggleTheme = toggleTheme;
window.toggleLanguage = toggleLanguage;
window.scrollToTop = scrollToTop;
